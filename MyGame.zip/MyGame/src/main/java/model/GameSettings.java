package model;

public class GameSettings {
    public int gameLevelCoefficient;
    public boolean isUserGameMuted ;
    public boolean isGameBlackAndWhite ;
}
