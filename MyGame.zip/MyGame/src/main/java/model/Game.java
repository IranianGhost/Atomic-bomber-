package model;

public class Game {
    public int kills;
    public int miss;
    public int lastWave;
    public int score;
    public int levelDegree;
    public Game(){
        this.kills = 0;
        this.miss = 0;
        this.lastWave = 1;
        this.score = 0;
        this.levelDegree = 0;

    }
}
