package model.objects;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.Objects;

public class Bomb extends Rectangle {
    public static final double WIDTH=20;
    public static final double HEIGHT=20;
    public Bomb(double x,double y) {
        super(WIDTH, HEIGHT);
        setX(x);
        setY(y);
        this.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/bomb.png")))));
    }
}
