package model.objects;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.Objects;


public class Plane extends Rectangle {

    public static final double WIDTH=80;
    public static final double HEIGHT=40;
    public static final double RightSpeed = 20/33.0;
    public static final double LeftSpeed = -20/33.0;
    public double speed=RightSpeed;
    public int health;
    public int kill;
    public int miss;
    public int clusters;
    public int nukes;
    ImagePattern right=new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/plane.png"))));
    ImagePattern left=new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/plane2.png"))));

    public Plane() {
        super(WIDTH,HEIGHT);
        setX(WIDTH/2);
        setY(HEIGHT/2+50);
        health=2;
        setRightFill();
        kill=0;
        miss=0;
        clusters=0;
        nukes=0;
    }
    public void setRightFill(){
        this.setFill(right);
    }
    public void setLeftFill(){
        this.setFill(left);
    }
}
