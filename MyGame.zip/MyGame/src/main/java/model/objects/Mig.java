package model.objects;

import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.Objects;

public class Mig extends Rectangle {
    public static final double WIDTH=70;
    public static final double HEIGHT=35;
    public Mig() {
        super(WIDTH, HEIGHT);
        setX(0);
        setY(50);
        this.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/mig.png")))));

    }
}
