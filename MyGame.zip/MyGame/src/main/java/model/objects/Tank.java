package model.objects;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import view.GameLauncher;
import view.animation.TankAnimation;

import java.util.Objects;


public class Tank extends Rectangle {
    public TankAnimation TankAnimation;
    public static final double WIDTH=100;
    public static final double HEIGHT=70;
    public boolean isHit= false;
    public Tank(double x) {
        super(WIDTH, HEIGHT);
        setX(x);
        setY(GameLauncher.HeightOfGround);
        this.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/tank.png")))));
    }

}
