package model.objects;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import view.GameLauncher;

import java.util.Objects;

public class Truck extends Rectangle {
    public static final double WIDTH=100;
    public static final double HEIGHT=70;
    public Truck() {
        super(WIDTH, HEIGHT);
        setX(800);
        setY(GameLauncher.HeightOfGround);
        this.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/truck.png")))));
    }
}
