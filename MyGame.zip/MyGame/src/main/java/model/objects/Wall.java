package model.objects;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import view.GameLauncher;

import java.util.Objects;


public class Wall extends Rectangle {
    public static final double WIDTH=40;
    public static final double HEIGHT=70;
    public Wall(double x) {
        super(WIDTH, HEIGHT);
        setX(x);
        setY(GameLauncher.HeightOfGround);
        this.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/wall.png")))));
    }
}
