package model;

import javafx.scene.image.Image;

import java.util.ArrayList;
import java.util.Objects;

public class User {
    public String username;
    public String password;
    public Image avatarImage;
    private static final ArrayList<User> users = new ArrayList<>();
    public static User loggedInUser;
    public GameSettings gameSettings;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.avatarImage = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/avatar1.png")));
        users.add(this);
        this.gameSettings=new GameSettings();
        this.gameSettings.gameLevelCoefficient = 1;
        this.gameSettings.isUserGameMuted=false;
        this.gameSettings.isGameBlackAndWhite=false;
    }
    public static User findUser(String username, String password) {
        for (User user : users) {
            if(user.username.equals(username) && user.password.equals(password)) {
                return user;
            }
        }
        return null;
    }
    public static boolean usernameExists(String username) {
        for (User user : users) {
            if(user.username.equals(username)) {
                return true;
            }
        }
        return false;
    }
    public static void deleteUser(User user) {
        users.remove(user);
    }
}
