package view.animation;
import javafx.animation.Transition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.objects.Building;
import model.objects.Plane;

public class DeadPlaneAnimation extends Transition {

    private final Plane plane;
    private final Scene scene;
    private final Stage stage;

    public DeadPlaneAnimation( Plane plane, Stage stage, Scene scene) {

        this.plane = plane;
        this.stage = stage;
        this.scene = scene;
        setCycleCount(1);
        setCycleDuration(Duration.millis(1000));
    }
    @Override
    protected void interpolate(double v) {
        int number=1;
        if(0<=v&&v<=0.33){
            number = 1;
        }
        else if(0.33<v&&v<=0.66){
            number = 2;
        }
        else if(0.66<v&&v<=1){
            number = 3;
        }
        plane.setFill(new ImagePattern(new Image(getClass().getResource("/Images/fire"+number+".png").toString())));
        this.setOnFinished(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent actionEvent) {
                stage.setScene(scene);
            }
        });

    }
}
