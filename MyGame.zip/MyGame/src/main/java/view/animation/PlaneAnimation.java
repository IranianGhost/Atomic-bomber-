package view.animation;

import controller.WinLoseController;
import javafx.animation.Transition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.Game;
import model.objects.Plane;

import java.io.IOException;

public class PlaneAnimation extends Transition {

    Plane plane;
    Pane pane;
    final double duration=33;
    Game game;
    Stage stage;
    boolean isStageChanged = false;
    public PlaneAnimation(Plane plane, Pane pane, Game game, Stage stage) {
        this.plane = plane;
        this.pane = pane;
        this.game = game;
        this.stage = stage;
        this.setCycleDuration(Duration.millis(duration));
        this.setCycleCount(-1);

    }

    @Override
    protected void interpolate(double v) {
        double x=plane.getX()+plane.speed;
        if(x<0){
            plane.setX(pane.getWidth()-plane.getWidth());
        }
        else if(x>pane.getWidth()-plane.getWidth()){
            plane.setX(0);
        }
        else {
            plane.setX(x);
        }
        if(plane.health<0&&!isStageChanged){
            isStageChanged=true;
            game.kills+=plane.kill;
            game.miss+=plane.miss;
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/WinLose.fxml"));
            Parent root = null; // Load the FXML file
            try {
                root = loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Pane pane2 = (Pane) root;
            WinLoseController controller = loader.getController(); // Now get the controller
            controller.WaveLable.setText(String.valueOf(game.lastWave));
            controller.KillsNumber.setText(String.valueOf(game.kills));
            if(game.miss==0){
                controller.Accuracy.setText("No miss");
            }
            else {
                double accuracy = (double)game.kills/(double)game.miss;
                controller.Accuracy.setText(String.valueOf(accuracy));
            }

            Scene scene = new Scene(pane2);
            this.stop();
            new DeadPlaneAnimation(plane,stage,scene).play();
        }
    }
}
