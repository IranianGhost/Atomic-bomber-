package view.animation;

import javafx.animation.Transition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.util.Duration;
import model.objects.Tank;

public class DeadTankAnimation extends Transition {
    private final Pane pane;
    private final Tank tank;

    public DeadTankAnimation(Pane pane, Tank tank) {
        this.pane = pane;
        this.tank = tank;
        setCycleCount(1);
        setCycleDuration(Duration.millis(1000));
    }
    @Override
    protected void interpolate(double v) {
        int number=1;
        if(0<=v&&v<=0.33){
            number = 1;
        }
        else if(0.33<v&&v<=0.66){
            number = 2;
        }
        else if(0.66<v&&v<=1){
            number = 3;
        }
        tank.setFill(new ImagePattern(new Image(getClass().getResource("/Images/deadtank"+number+".png").toString())));
        this.setOnFinished(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent actionEvent) {
                pane.getChildren().remove(tank);
            }
        });

    }
}
