package view.animation;

import javafx.animation.Transition;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import model.objects.Plane;
import model.objects.TankShot;

public class TankShotAnimation extends Transition {
    Pane pane;
    Plane plane;
    TankShot tankShot;
    double speed=-30/33.3;
    final double duration=33;
    public TankShotAnimation(Pane pane, Plane plane, TankShot tankShot) {
        this.pane = pane;
        this.plane = plane;
        this.tankShot = tankShot;
        this.setCycleDuration(Duration.millis(duration));
        this.setCycleCount(-1);
    }
    @Override
    protected void interpolate(double v) {
        double y=tankShot.getY()+speed;

        if(tankShot.getBoundsInParent().intersects(plane.getBoundsInParent())) {
            plane.health--;
            pane.getChildren().remove(tankShot);
            this.stop();
        }

        if(y<0){
            pane.getChildren().remove(tankShot);
            this.stop();
        }
        tankShot.setY(y);
    }
}
