package view.animation;

import javafx.animation.Transition;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import model.objects.Bomb;
import model.objects.Building;
import model.objects.Plane;
import model.objects.Tank;
import view.GameLauncher;

public class BombAnimation extends Transition {
    Pane pane;
    Bomb bomb;
    Group enemies;
    Plane plane;
    double horizontalSpeed;
    final double duration=33;
    boolean isNuke;
    public BombAnimation(Pane pane, Bomb bomb, double planeSpeed, Group enemies, Plane plane, boolean isNuke) {
        this.pane = pane;
        this.bomb=bomb;
        this.enemies = enemies;
        this.plane = plane;
        this.isNuke=isNuke;
        horizontalSpeed = planeSpeed;
        this.setCycleDuration(Duration.millis(duration));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate(double v) {
        double x=bomb.getX() + horizontalSpeed*2;
        double y=bomb.getY()+100/33.0;
        if(bomb.getY()> pane.getHeight()-100){
            plane.miss++;
            this.stop();
            if(isNuke){
                new NukeAnimation(pane,bomb).play();
            }
            else new DeadBombAnimation(pane,bomb).play();
        }
        for(Node n:enemies.getChildren()){
            if(bomb.getBoundsInParent().intersects(n.getBoundsInParent())){
                enemies.getChildren().remove(n);
                if (n instanceof Tank){
                    ((Tank) n).TankAnimation.stop();
                    pane.getChildren().add(n);
                    new DeadTankAnimation(pane,(Tank) n).play();
                }
                if(n instanceof Building){
                    pane.getChildren().add(n);
                    new DeadBuildingAnimation(pane,(Building) n).play();
                }
                pane.getChildren().remove(bomb);
                plane.kill++;
                GameLauncher.changeKill(plane.kill);
                this.stop();
                break;
            }
        }

        bomb.setX(x);
        bomb.setY(y);
    }
}
