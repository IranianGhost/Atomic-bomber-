package view.animation;

import javafx.animation.Transition;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import model.objects.Bomb;
import model.objects.Plane;
import model.objects.Tank;

public class MigShotAnimation extends Transition {
    Pane pane;
    Rectangle shot;
    Plane plane;
    final double duration=33;
    public MigShotAnimation(Pane pane, Rectangle shot, Plane plane) {
        this.pane = pane;
        this.shot=shot;
        this.plane=plane;
        this.setCycleDuration(Duration.millis(duration));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate(double v) {
        double y=shot.getY()+50/33.0;
        if(shot.getY()> pane.getHeight()-100){
            pane.getChildren().remove(shot);
            this.stop();
        }
        if(shot.getBoundsInParent().intersects(plane.getBoundsInParent())){
            plane.health--;
            pane.getChildren().remove(shot);
            this.stop();
        }

        shot.setY(y);
    }
}
