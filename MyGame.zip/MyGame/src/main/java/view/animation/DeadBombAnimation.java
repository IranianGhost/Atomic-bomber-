package view.animation;

import javafx.animation.Transition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.util.Duration;
import model.objects.Bomb;
import model.objects.Tank;

public class DeadBombAnimation extends Transition {
    private final Pane pane;
    private final Bomb bomb;

    public DeadBombAnimation(Pane pane, Bomb bomb) {
        this.pane = pane;
        this.bomb = bomb;
        setCycleCount(1);
        setCycleDuration(Duration.millis(1000));
    }
    @Override
    protected void interpolate(double v) {
        int number=1;
        if(0<=v&&v<=0.33){
            number = 1;
        }
        else if(0.33<v&&v<=0.66){
            number = 2;
        }
        else if(0.66<v&&v<=1){
            number = 3;
        }
        bomb.setFill(new ImagePattern(new Image(getClass().getResource("/Images/blast"+number+".png").toString())));
        this.setOnFinished(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent actionEvent) {
                pane.getChildren().remove(bomb);
            }
        });

    }
}
