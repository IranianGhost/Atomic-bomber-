package view.animation;

import javafx.animation.Transition;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import model.objects.Mig;
import model.objects.Plane;

import java.util.Objects;

public class MigAnimation extends Transition {

    Mig mig;
    Pane pane;
    Plane plane;
    final double duration=33;
    public static final double Speed = 40/33.0;
    Group enemies;
    boolean hasShot=false;
    public MigAnimation(Mig mig, Pane pane, Group enemies,Plane plane) {
        this.mig = mig;
        this.pane = pane;
        this.enemies = enemies;
        this.plane = plane;
        this.setCycleDuration(Duration.millis(duration));
        this.setCycleCount(-1);
    }
    @Override
    protected void interpolate(double v) {
        double x=mig.getX()+Speed;
        if(x>pane.getWidth()){
            enemies.getChildren().remove(mig);
            this.stop();
        }
        if(norm(x-plane.getX())<10&&!hasShot){
            shot();
            hasShot=true;
        }
        mig.setX(x);
    }

    private void shot() {
        Rectangle shot=new Rectangle(20,20);
        shot.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/shot.png")))));
        shot.setX(mig.getX()+mig.getWidth()/2);
        shot.setY(mig.getY()+mig.getHeight()/2);
        pane.getChildren().add(shot);
        MigShotAnimation migShotAnimation=new MigShotAnimation(pane,shot,plane);
        migShotAnimation.play();
    }


    double norm(double x){
        if(x<0) x=-x;
        return x;
    }
}
