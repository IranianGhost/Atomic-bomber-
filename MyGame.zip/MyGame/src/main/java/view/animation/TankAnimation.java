package view.animation;

import javafx.animation.Transition;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import model.objects.Plane;
import model.objects.Tank;
import model.objects.TankShot;

public class TankAnimation extends Transition {
    Plane plane;
    Pane pane;
    Tank tank;
    final double duration=33;
    static double speed=40/33.0;
    public boolean hasShoot=false;
    public TankAnimation(Plane plane, Pane pane, Tank tank) {
        this.plane = plane;
        this.pane = pane;
        this.tank = tank;
        this.setCycleDuration(Duration.millis(duration));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate(double v) {
        double x=tank.getX()+speed;

        if(norm(tank.getX()-plane.getX())<50&&!hasShoot){
            hasShoot=true;
            shoot();
        }
        if(x>pane.getWidth()-tank.getWidth()){
            tank.setX(0);
        }
        else {
            tank.setX(x);
        }
        
    }

    private void shoot() {
        TankShot tankShot= new TankShot(tank.getX()+tank.getWidth(),tank.getY());
        pane.getChildren().add(tankShot);
        TankShotAnimation tankShotAnimation= new TankShotAnimation(pane,plane,tankShot);
        tankShotAnimation.play();
    }

    private double norm(double x){
        if(x<0){
            x=x*(-1);
        }
        return x;
    }
}
