package view;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import model.Game;
import model.objects.*;
import view.animation.BombAnimation;
import view.animation.PlaneAnimation;
import view.animation.TankAnimation;

import java.util.Objects;

public class Wave1 {
    Game game;
    Stage stage;
    Pane pane;
    public Wave1(Stage stage,Pane pane,Game game) {
        this.stage = stage;
        this.pane = pane;
        this.game = game;
        action();
    }
    private void action(){
        Plane plane = new Plane();
        pane.getChildren().add(plane);
        Group enemies = new Group();
        pane.getChildren().add(enemies);
        plane.requestFocus();
        plane.setOnKeyPressed(keyEvent -> {
            if(keyEvent.getCode()== KeyCode.RIGHT){
                plane.setRightFill();
                plane.speed=Plane.RightSpeed;
            }
            else if(keyEvent.getCode()== KeyCode.LEFT){
                plane.setLeftFill();
                plane.speed=Plane.LeftSpeed;
            }
            else if(keyEvent.getCode()== KeyCode.UP){
                plane.setY(Double.max(plane.getY()-50,50));
            }
            else if(keyEvent.getCode()== KeyCode.DOWN){
                plane.setY(Double.min(plane.getY()+50,pane.getHeight()-200));
            }
            else if(keyEvent.getCode()== KeyCode.SPACE){
                Bomb bomb = new Bomb(plane.getX()+plane.getWidth()/2,plane.getY()+plane.getHeight());
                pane.getChildren().add(bomb);
                new BombAnimation(pane,bomb,plane.speed,enemies,plane,false).play();
            }
            else if(keyEvent.getCode()== KeyCode.ENTER){
                if(enemies.getChildren().isEmpty()){
                    pane.getChildren().remove(plane);
                    pane.getChildren().remove(enemies);
                    game.kills+=plane.kill;
                    game.lastWave++;
                    game.miss+=plane.miss;
                    GameLauncher.changeWave(2);
                    GameLauncher.changeAccuracy((double) plane.kill/(double) plane.miss);
                    GameLauncher.changeNuke(0);
                    GameLauncher.changeCluster(0);
                    GameLauncher.changeKill(0);
                    new Wave2(stage,pane,game);
                }
            }
            else if(keyEvent.getCode()== KeyCode.P){
                pane.getChildren().remove(plane);
                pane.getChildren().remove(enemies);
                game.lastWave++;
                GameLauncher.changeWave(2);
                GameLauncher.changeNuke(0);
                GameLauncher.changeCluster(0);
                GameLauncher.changeKill(0);
                new Wave2(stage,pane,game);
            }
            else if(keyEvent.getCode()== KeyCode.G){
                plane.nukes++;
                GameLauncher.changeNuke(plane.nukes);
            }
            else if(keyEvent.getCode()== KeyCode.W){
                plane.clusters++;
                GameLauncher.changeCluster(plane.clusters);
            }
            else if(keyEvent.getCode()== KeyCode.H){
                plane.health=3;
            }
            else if(keyEvent.getCode()== KeyCode.T){
                Tank tank=new Tank((Math.random()*((pane.getWidth()-50)+1))+50);
                TankAnimation tankAnimation= new TankAnimation(plane,pane,tank);
                tank.TankAnimation=tankAnimation;
                tankAnimation.play();
                enemies.getChildren().add(tank);
            }
            else if(keyEvent.getCode()== KeyCode.R){
                if(plane.nukes>0){
                    plane.nukes--;
                    Bomb bomb = new Bomb(plane.getX()+plane.getWidth()/2,plane.getY()+plane.getHeight());
                    bomb.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/nuke.png")))));
                    pane.getChildren().add(bomb);
                    new BombAnimation(pane,bomb,plane.speed,enemies,plane,true).play();
                }
            }
            else if(keyEvent.getCode()== KeyCode.C){
                if(plane.clusters>0){
                    plane.clusters--;
                    Bomb bomb = new Bomb(plane.getX()+plane.getWidth()/2,plane.getY()+plane.getHeight());
                    bomb.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/nuke.png")))));
                    pane.getChildren().add(bomb);
                    new BombAnimation(pane,bomb,Plane.LeftSpeed,enemies,plane,true).play();
                    Bomb bomb2 = new Bomb(plane.getX()+plane.getWidth()/2,plane.getY()+plane.getHeight());
                    bomb2.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/nuke.png")))));
                    pane.getChildren().add(bomb2);
                    new BombAnimation(pane,bomb2,Plane.RightSpeed,enemies,plane,true).play();
                    Bomb bomb3 = new Bomb(plane.getX()+plane.getWidth()/2,plane.getY()+plane.getHeight());
                    bomb3.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/nuke.png")))));
                    pane.getChildren().add(bomb3);
                    new BombAnimation(pane,bomb3,0,enemies,plane,true).play();

                }
            }
        });

        PlaneAnimation planeAnimation=new PlaneAnimation(plane,pane,game,stage);
        planeAnimation.play();

        Wall wall=new Wall(100);
        enemies.getChildren().add(wall);
        Tree tree=new Tree(145);
        enemies.getChildren().add(tree);
        Truck truck=new Truck();
        enemies.getChildren().add(truck);
//        Truck truck2=new Truck();
//        enemies.getChildren().add(truck2);
        Building building=new Building();
        enemies.getChildren().add(building);
    }
}
