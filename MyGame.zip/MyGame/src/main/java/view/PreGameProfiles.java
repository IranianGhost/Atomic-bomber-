package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;


public class PreGameProfiles extends Application {

    public static Stage appStage;
    @Override
    public void start(Stage stage) throws Exception {
        appStage = stage;
        Scene scene = getProfileScene();
        stage.setScene(scene);



    }

    public static Scene getProfileScene() throws IOException {
        Pane pane = FXMLLoader.load(Objects.requireNonNull(PreGameProfiles.class.getResource("/FXML/ProfileMenu.fxml")));
        Scene scene = new Scene(pane);
        return scene;
    }
    public static Scene getAvatarScene() throws IOException {
        Pane pane = FXMLLoader.load(Objects.requireNonNull(PreGameProfiles.class.getResource("/FXML/AvatarMenu.fxml")));
        Scene scene = new Scene(pane);
        return scene;
    }

    public static Scene getSettingScene() throws IOException {
        Pane pane = FXMLLoader.load(Objects.requireNonNull(PreGameProfiles.class.getResource("/FXML/SettingMenu.fxml")));
        Scene scene = new Scene(pane);
        return scene;
    }
    public static Scene getMainScene() throws IOException {
        Pane pane = FXMLLoader.load(Objects.requireNonNull(PreGameProfiles.class.getResource("/FXML/MainMenu.fxml")));
        Scene scene = new Scene(pane);
        return scene;
    }

}
