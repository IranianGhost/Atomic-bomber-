package view;

import controller.WinLoseController;
import javafx.animation.PauseTransition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.Game;
import model.objects.*;
import view.animation.BombAnimation;
import view.animation.MigAnimation;
import view.animation.PlaneAnimation;
import view.animation.TankAnimation;

import java.io.IOException;
import java.util.Objects;

public class Wave3 {
    Stage stage;
    Pane pane;
    Game game;
    public Wave3(Stage stage, Pane pane, Game game) {
        this.stage = stage;
        this.pane = pane;
        this.game = game;
        action();
    }
    private void action(){
        Plane plane = new Plane();
        pane.getChildren().add(plane);
        Group enemies = new Group();
        pane.getChildren().add(enemies);
        plane.requestFocus();
        plane.setOnKeyPressed(keyEvent -> {
            if(keyEvent.getCode()== KeyCode.RIGHT){
                plane.setRightFill();
                plane.speed=Plane.RightSpeed;
            }
            else if(keyEvent.getCode()== KeyCode.LEFT){
                plane.setLeftFill();
                plane.speed=Plane.LeftSpeed;
            }
            else if(keyEvent.getCode()== KeyCode.UP){
                plane.setY(Double.max(plane.getY()-50,50));
            }
            else if(keyEvent.getCode()== KeyCode.DOWN){
                plane.setY(Double.min(plane.getY()+50,pane.getHeight()-200));
            }
            else if(keyEvent.getCode()== KeyCode.SPACE){
                Bomb bomb = new Bomb(plane.getX()+plane.getWidth()/2,plane.getY()+plane.getHeight());
                pane.getChildren().add(bomb);
                new BombAnimation(pane,bomb,plane.speed,enemies,plane,false).play();
            }
            else if(keyEvent.getCode()== KeyCode.ENTER){
                if(enemies.getChildren().isEmpty()){
                    game.kills+=plane.kill;
                    game.lastWave++;
                    game.miss+=plane.miss;
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/WinLose.fxml"));
                    Parent root = null; // Load the FXML file
                    try {
                        root = loader.load();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    Pane pane2 = (Pane) root;
                    WinLoseController controller = loader.getController(); // Now get the controller
                    controller.WaveLable.setText("3");
                    controller.KillsNumber.setText(String.valueOf(game.kills));
                    if(game.kills==0){
                        controller.Accuracy.setText("0");
                    }
                    else {
                        double accuracy = (double)game.kills/(double)game.miss;
                        controller.Accuracy.setText(String.valueOf(accuracy));
                    }
                    controller.WLlable.setText("You won");

                    Scene scene = new Scene(pane2);
                    stage.setScene(scene);
                }
            }

            else if(keyEvent.getCode()== KeyCode.G){
                plane.nukes++;
                GameLauncher.changeNuke(plane.nukes);
            }
            else if(keyEvent.getCode()== KeyCode.W){
                plane.clusters++;
                GameLauncher.changeCluster(plane.clusters);
            }
            else if(keyEvent.getCode()== KeyCode.H){
                plane.health=3;
            }
            else if(keyEvent.getCode()== KeyCode.T){
                Tank tank=new Tank((Math.random()*((pane.getWidth()-50)+1))+50);
                TankAnimation tankAnimation= new TankAnimation(plane,pane,tank);
                tank.TankAnimation=tankAnimation;
                tankAnimation.play();
                enemies.getChildren().add(tank);
            }
            else if(keyEvent.getCode()== KeyCode.R){
                if(plane.nukes>0){
                    plane.nukes--;
                    Bomb bomb = new Bomb(plane.getX()+plane.getWidth()/2,plane.getY()+plane.getHeight());
                    bomb.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/nuke.png")))));
                    pane.getChildren().add(bomb);
                    new BombAnimation(pane,bomb,plane.speed,enemies,plane,true).play();
                }
            }
            else if(keyEvent.getCode()== KeyCode.C){
                if(plane.clusters>0){
                    plane.clusters--;
                    Bomb bomb = new Bomb(plane.getX()+plane.getWidth()/2,plane.getY()+plane.getHeight());
                    bomb.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/nuke.png")))));
                    pane.getChildren().add(bomb);
                    new BombAnimation(pane,bomb,Plane.LeftSpeed,enemies,plane,true).play();
                    Bomb bomb2 = new Bomb(plane.getX()+plane.getWidth()/2,plane.getY()+plane.getHeight());
                    bomb2.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/nuke.png")))));
                    pane.getChildren().add(bomb2);
                    new BombAnimation(pane,bomb2,Plane.RightSpeed,enemies,plane,true).play();
                    Bomb bomb3 = new Bomb(plane.getX()+plane.getWidth()/2,plane.getY()+plane.getHeight());
                    bomb3.setFill(new ImagePattern(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/nuke.png")))));
                    pane.getChildren().add(bomb3);
                    new BombAnimation(pane,bomb3,0,enemies,plane,true).play();

                }
            }
        });

        PlaneAnimation planeAnimation=new PlaneAnimation(plane,pane,game,stage);
        planeAnimation.play();

        Wall wall=new Wall(100);
        enemies.getChildren().add(wall);
        Tree tree=new Tree(145);
        enemies.getChildren().add(tree);
        for (int i = 0; i <3; i++) {
            Tank tank=new Tank(100+i*Tank.WIDTH);
            TankAnimation tankAnimation= new TankAnimation(plane,pane,tank);
            tank.TankAnimation=tankAnimation;
            tankAnimation.play();
            enemies.getChildren().add(tank);
        }
        Truck truck=new Truck();
        enemies.getChildren().add(truck);
        Building building=new Building();
        enemies.getChildren().add(building);
        PauseTransition pause = new PauseTransition(Duration.seconds(3));

        pause.setOnFinished(event -> {
            Mig mig=new Mig();
            enemies.getChildren().add(mig);
            MigAnimation migAnimation= new MigAnimation(mig,pane,enemies,plane);
            migAnimation.play();
        });
        pause.play();

    }
}
