package view;

import controller.GameEnvironmentController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;

import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Game;
import model.GameSettings;

import java.util.Objects;


public class GameLauncher extends Application {
    public static double HeightOfGround=420;
    public static Stage appStage;
    public static GameEnvironmentController controller;
    @Override
    public void start(Stage stage) throws Exception {
        appStage = stage;
        stage.getIcons().add(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/icon.png"))));
        FXMLLoader loader= new FXMLLoader(Objects.requireNonNull(getClass().getResource("/FXML/GameEnvironment.fxml")));;
        Pane pane = loader.load();
        controller = loader.getController();
        Image image = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/environment.png")));
        BackgroundImage backgroundImage = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                new BackgroundSize(1.0, 1.0, true, true, false, false));
        pane.setBackground(new Background(backgroundImage));
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        Game game = new Game();
        stage.show();
        new Wave1(stage,pane,game);
    }
    public static void changeWave(int num){
        controller.NumWave.setText(String.valueOf(num));
    }
    public static void changeKill(int num){
        controller.NumKills.setText(String.valueOf(num));
    }
    public static void changeCluster(int num){
        controller.NumClusters.setText(String.valueOf(num));
    }
    public static void changeNuke(int num){
        controller.NumNukes.setText(String.valueOf(num));
    }
    public static void changeAccuracy(double num){
        controller.NumAccuracy.setText(String.valueOf(num));
    }



}
