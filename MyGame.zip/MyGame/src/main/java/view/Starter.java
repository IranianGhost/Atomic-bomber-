package view;


public class Starter {
    public static void main(String[] args) {
        RegisterMenu.main(args);
    }
}
