module MyGame {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;
    requires java.desktop;

    exports view;
    exports controller to javafx.fxml;

    opens view to javafx.fxml;
    opens controller to javafx.fxml;
}
