package controller;

import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import model.User;
import view.PreGameProfiles;
import view.RegisterMenu;

import java.io.IOException;

public class ProfileMenuController {

    public TextField NewUsername;
    public PasswordField NewPassword;
    public CheckBox DeleteCheckBox;
    public Label UpdateResult;

    public void openAvatarMenu(MouseEvent mouseEvent) throws IOException {
        PreGameProfiles.appStage.setScene(PreGameProfiles.getAvatarScene());
    }

    public void logoutUser(MouseEvent mouseEvent) throws Exception {
        User.loggedInUser=null;
        new RegisterMenu().start(PreGameProfiles.appStage);
    }

    public void openMainMenu(MouseEvent mouseEvent) throws IOException {
        PreGameProfiles.appStage.setScene(PreGameProfiles.getMainScene());
    }

    public void updateUsername(MouseEvent mouseEvent) {
        if(NewUsername.getText().isEmpty()) {
            UpdateResult.setText("You must enter a username");
            return;
        }
        if(NewUsername.getText().equals(User.loggedInUser.username)){
            UpdateResult.setText("Username should be different than the current one");
            return;
        }
        User.loggedInUser.username=NewUsername.getText();
        UpdateResult.setText("Username updated successfully");
    }

    public void deleteUser(MouseEvent mouseEvent) throws Exception {
        if(!DeleteCheckBox.isSelected()) {
            return;
        }
        User.deleteUser(User.loggedInUser);
        User.loggedInUser=null;
        new RegisterMenu().start(PreGameProfiles.appStage);
    }

    public void updatePassword(MouseEvent mouseEvent) {
        if(NewPassword.getText().isEmpty()) {
            UpdateResult.setText("You must enter a password");
            return;
        }
        if(NewPassword.getText().equals(User.loggedInUser.password)){
            UpdateResult.setText("Password should be different than the current one");
            return;
        }
        User.loggedInUser.password=NewPassword.getText();
        UpdateResult.setText("Password updated successfully");
    }
}
