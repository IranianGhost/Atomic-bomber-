package controller;

import javafx.scene.control.Label;

public class GameEnvironmentController {

    public Label NumKills;
    public Label NumAccuracy;
    public Label NumNukes;
    public Label NumWave;
    public Label NumClusters;
}
