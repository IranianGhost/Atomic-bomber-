package controller;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.stage.FileChooser;
import model.User;
import view.PreGameProfiles;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Objects;

public class AvatarMenuController {

    public Button chooseAvatar;
    public ImageView CurrentAvatar;
    public RadioButton Avatar1box;
    public RadioButton Avatar2box;
    public RadioButton Avatar3box;
    public Label SaveChangesResult;
    private ToggleGroup group;


    public void initialize() {
        group = new ToggleGroup();
        Avatar1box.setToggleGroup(group);
        Avatar2box.setToggleGroup(group);
        Avatar3box.setToggleGroup(group);
        CurrentAvatar.setImage(User.loggedInUser.avatarImage);
    }

    public void Avatar1Action() {
        CurrentAvatar.setImage(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/avatar1.png"))));
    }

    public void Avatar2Action() {
        CurrentAvatar.setImage(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/avatar2.png"))));    }

    public void Avatar3Action() {
        CurrentAvatar.setImage(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/avatar3.png"))));    }

    public void chooseCustomFile() throws MalformedURLException {
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            String imagePath = file.toURI().toURL().toString();
            Image image = new Image(imagePath);
            CurrentAvatar.setImage(image);
        }
    }

    public void saveAvatarChange(MouseEvent mouseEvent) {
        if(CurrentAvatar.getImage() == null) {
            SaveChangesResult.setText("You have not selected an avatar");
            return;
        }
        User.loggedInUser.avatarImage = CurrentAvatar.getImage();
        SaveChangesResult.setText("Changes saved Successfully");
    }

    public void backToProfileMenu(MouseEvent mouseEvent) throws IOException {
        PreGameProfiles.appStage.setScene(PreGameProfiles.getProfileScene());
    }

    public void dragOver(DragEvent event) {
        if (event.getDragboard().hasFiles()) {
            event.acceptTransferModes(TransferMode.ANY);
        }
    }

    public void dragDropped(DragEvent event) throws MalformedURLException {
        File file = event.getDragboard().getFiles().get(0);
        if (file != null) {
            String imagePath = file.toURI().toURL().toString();
            Image image = new Image(imagePath);
            CurrentAvatar.setImage(image);
        }
    }

}
