package controller;

import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import model.User;
import view.PreGameProfiles;

import java.io.IOException;

public class SettingMenuController {


    public Label GameLevelLabel;
    public Label MuteResult;
    public Label BlackAndWhiteResult;

    public void initialize() {
        if(User.loggedInUser.gameSettings.isGameBlackAndWhite) {
            BlackAndWhiteResult.setText("Game is black and white");
        }
        else {
            BlackAndWhiteResult.setText("Game is not black and white");
        }
        if(User.loggedInUser.gameSettings.isUserGameMuted) {
            MuteResult.setText("Game is muted");
        }
        else {
            MuteResult.setText("Game is not muted");
        }
        int temp=User.loggedInUser.gameSettings.gameLevelCoefficient;
        if(temp==1) {
            GameLevelLabel.setText("Easy");
        }
        if(temp==2) {
            GameLevelLabel.setText("Hard");
        }
        if(temp==3) {
            GameLevelLabel.setText("You are not going to make it");
        }

    }

    public void makeGameEasy(MouseEvent mouseEvent) {
        User.loggedInUser.gameSettings.gameLevelCoefficient=1;
        GameLevelLabel.setText("Easy");
    }

    public void makeGameHard(MouseEvent mouseEvent) {
        User.loggedInUser.gameSettings.gameLevelCoefficient=2;
        GameLevelLabel.setText("Hard");
    }

    public void makeGameGodMode(MouseEvent mouseEvent) {
        User.loggedInUser.gameSettings.gameLevelCoefficient=3;
        GameLevelLabel.setText("You are not going to make it");
    }

    public void changeMute(MouseEvent mouseEvent) {
        User.loggedInUser.gameSettings.isUserGameMuted=!User.loggedInUser.gameSettings.isUserGameMuted;
        if(User.loggedInUser.gameSettings.isUserGameMuted) {
            MuteResult.setText("Game is muted");
        }
        else {
            MuteResult.setText("Game is not muted");
        }
    }

    public void backToMainMenu(MouseEvent mouseEvent) throws IOException {
        PreGameProfiles.appStage.setScene(PreGameProfiles.getMainScene());
    }

    public void changeBlackAndWhite(MouseEvent mouseEvent) {
        User.loggedInUser.gameSettings.isGameBlackAndWhite=!User.loggedInUser.gameSettings.isGameBlackAndWhite;
        if(User.loggedInUser.gameSettings.isGameBlackAndWhite) {
            BlackAndWhiteResult.setText("Game is black and white");
        }
        else {
            BlackAndWhiteResult.setText("Game is not black and white");
        }
    }
}
