package controller;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import model.User;
import view.PreGameProfiles;
import view.RegisterMenu;

import java.util.Random;


public class RegisterMenuController {
    public TextField UserName;
    public PasswordField Password;
    public Label ErrorText;
    public Button LoginButton;

    public void loginAction(MouseEvent mouseEvent) throws Exception {
        if (UserName.getText().isEmpty() || Password.getText().isEmpty()) {
            ErrorText.setText("Please fill all the fields");
            return;
        }
        User u= User.findUser(UserName.getText(), Password.getText());
        if(u == null) {
            ErrorText.setText("username or password is incorrect");
            return;
        }
        User.loggedInUser=u;
        new PreGameProfiles().start(RegisterMenu.appStage);

    }

    public void registerAction(MouseEvent mouseEvent) {
        if (UserName.getText().isEmpty() || Password.getText().isEmpty()) {
            ErrorText.setText("Please fill all the fields");
            return;
        }
        if(User.usernameExists(UserName.getText())){
            ErrorText.setText("User Exist");
            return;
        }
        new User(UserName.getText(), Password.getText());
        ErrorText.setText("New User successfully created");
    }

    public void skipAction(MouseEvent mouseEvent) throws Exception {
        String username= "Guest"+ random(1000,9999);
        String password= "1111";
        User.loggedInUser= new User(username, password);
        new PreGameProfiles().start(RegisterMenu.appStage);
    }

    private static int random(int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
}
