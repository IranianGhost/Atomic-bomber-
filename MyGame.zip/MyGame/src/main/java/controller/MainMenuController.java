package controller;

import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import model.User;
import view.GameLauncher;
import view.PreGameProfiles;

import java.io.IOException;

public class MainMenuController {
    public Label LabelOfUsername;
    public ImageView ImageOfUserAvatar;

    public void initialize() {
        LabelOfUsername.setText(User.loggedInUser.username);
        ImageOfUserAvatar.setImage(User.loggedInUser.avatarImage);
    }
    public void backToProfileMenu(MouseEvent mouseEvent) throws IOException {
        PreGameProfiles.appStage.setScene(PreGameProfiles.getProfileScene());
    }

    public void settingMenu(MouseEvent mouseEvent) throws IOException {
        PreGameProfiles.appStage.setScene(PreGameProfiles.getSettingScene());
    }

    public void startNewGame(MouseEvent mouseEvent) throws Exception {
        new GameLauncher().start(PreGameProfiles.appStage);
    }

    public void showRatings(MouseEvent mouseEvent) {

    }

    public void continueLastGame(MouseEvent mouseEvent) {

    }
}
