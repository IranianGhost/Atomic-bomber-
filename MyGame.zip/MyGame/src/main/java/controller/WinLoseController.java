package controller;

import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import view.GameLauncher;
import view.PreGameProfiles;

import java.io.IOException;

public class WinLoseController {
    public Label WLlable;
    public Label WaveLable;
    public Label KillsNumber;
    public Label Accuracy;


    public void BackToMainMenu(MouseEvent mouseEvent) throws IOException {
        GameLauncher.appStage.setScene(PreGameProfiles.getMainScene());
    }

}
